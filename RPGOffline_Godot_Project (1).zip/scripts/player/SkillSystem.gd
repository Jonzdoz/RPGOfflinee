class_name SkillSystem
extends Node

## Habilidades entrenables de forma independiente.
enum SkillType {
    MELEE,
    RANGED,
    MAGIC,
    DEFENSE,
}

## Tipos de arma que determinan qué habilidad ofensiva recibe experiencia.
enum WeaponType {
    MELEE,
    BOW,
    STAFF,
}

signal skill_experience_changed(skill: SkillType, current_xp: int, xp_to_next_level: int)
signal skill_level_up(skill: SkillType, new_level: int)
signal weapon_changed(new_weapon: WeaponType)

@export_category("Experience")
@export var experience_base: int = 100
@export var experience_growth: float = 1.35

## Diccionarios con cuatro progresiones totalmente separadas.
var skill_levels: Dictionary = {}
var skill_experience: Dictionary = {}

var current_weapon: WeaponType = WeaponType.MELEE


func _ready() -> void:
    for skill in SkillType.values():
        skill_levels[skill] = 1
        skill_experience[skill] = 0


## Devuelve la experiencia total necesaria para alcanzar un nivel concreto.
## Nivel 1 necesita 0 XP; nivel 2 necesita experience_base XP.
func get_total_xp_for_level(level: int) -> int:
    if level <= 1:
        return 0
    return int(round(experience_base * pow(float(level - 1), experience_growth)))


## XP restante para llegar al siguiente nivel desde el nivel actual.
func get_xp_to_next_level(skill: SkillType) -> int:
    var level: int = get_skill_level(skill)
    var current_xp: int = get_skill_experience(skill)
    return maxi(get_total_xp_for_level(level + 1) - current_xp, 0)


func get_skill_level(skill: SkillType) -> int:
    return int(skill_levels.get(skill, 1))


func get_skill_experience(skill: SkillType) -> int:
    return int(skill_experience.get(skill, 0))


## Convierte las claves enum en nombres estables para JSON.
func get_save_data() -> Dictionary:
    return {
        "melee": {
            "level": get_skill_level(SkillType.MELEE),
            "experience": get_skill_experience(SkillType.MELEE),
        },
        "ranged": {
            "level": get_skill_level(SkillType.RANGED),
            "experience": get_skill_experience(SkillType.RANGED),
        },
        "magic": {
            "level": get_skill_level(SkillType.MAGIC),
            "experience": get_skill_experience(SkillType.MAGIC),
        },
        "defense": {
            "level": get_skill_level(SkillType.DEFENSE),
            "experience": get_skill_experience(SkillType.DEFENSE),
        },
        "weapon": int(current_weapon),
    }


## Restaura datos leídos desde JSON sin depender de claves numéricas del enum.
func load_save_data(data: Dictionary) -> void:
    var skill_names := {
        "melee": SkillType.MELEE,
        "ranged": SkillType.RANGED,
        "magic": SkillType.MAGIC,
        "defense": SkillType.DEFENSE,
    }

    for skill_name in skill_names:
        var skill_data: Dictionary = data.get(skill_name, {})
        if skill_data.is_empty():
            continue

        var skill: SkillType = skill_names[skill_name]
        skill_levels[skill] = maxi(int(skill_data.get("level", 1)), 1)
        skill_experience[skill] = maxi(int(skill_data.get("experience", 0)), 0)
        skill_experience_changed.emit(
            skill,
            skill_experience[skill],
            get_xp_to_next_level(skill)
        )

    var saved_weapon: int = clampi(int(data.get("weapon", WeaponType.MELEE)), 0, WeaponType.size() - 1)
    set_weapon(saved_weapon as WeaponType)


## Añade XP a una habilidad y procesa uno o varios niveles si corresponde.
func add_experience(skill: SkillType, amount: int) -> void:
    if amount <= 0:
        return

    var total_xp: int = get_skill_experience(skill) + amount
    skill_experience[skill] = total_xp

    var level: int = get_skill_level(skill)
    while total_xp >= get_total_xp_for_level(level + 1):
        level += 1
        skill_levels[skill] = level
        skill_level_up.emit(skill, level)

    skill_experience_changed.emit(
        skill,
        total_xp,
        get_xp_to_next_level(skill)
    )


## Se llama una sola vez cuando un ataque realmente conecta con el objetivo.
func register_attack_hit(experience_amount: int = 10) -> void:
    add_experience(get_attack_skill_for_weapon(), experience_amount)


## Defensa se entrena al recibir daño real, no al iniciar un ataque enemigo.
func register_damage_received(damage_amount: int) -> void:
    add_experience(SkillType.DEFENSE, damage_amount)


func get_attack_skill_for_weapon() -> SkillType:
    match current_weapon:
        WeaponType.MELEE:
            return SkillType.MELEE
        WeaponType.BOW:
            return SkillType.RANGED
        WeaponType.STAFF:
            return SkillType.MAGIC
    return SkillType.MELEE


func set_weapon(new_weapon: WeaponType) -> void:
    if current_weapon == new_weapon:
        return

    current_weapon = new_weapon
    weapon_changed.emit(current_weapon)


## Alterna en orden: Cuerpo a cuerpo -> Arco -> Báculo -> Cuerpo a cuerpo.
func cycle_weapon() -> WeaponType:
    var next_weapon: int = (int(current_weapon) + 1) % WeaponType.size()
    set_weapon(next_weapon as WeaponType)
    return current_weapon


func get_weapon_name(weapon: WeaponType = current_weapon) -> String:
    match weapon:
        WeaponType.MELEE:
            return "Cuerpo a cuerpo"
        WeaponType.BOW:
            return "Arco"
        WeaponType.STAFF:
            return "Báculo"
    return "Desconocida"


func get_skill_name(skill: SkillType) -> String:
    match skill:
        SkillType.MELEE:
            return "Melee"
        SkillType.RANGED:
            return "Distancia"
        SkillType.MAGIC:
            return "Magia"
        SkillType.DEFENSE:
            return "Defensa"
    return "Desconocida"
