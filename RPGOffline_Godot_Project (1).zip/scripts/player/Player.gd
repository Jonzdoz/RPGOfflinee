class_name Player
extends CharacterBody2D

signal died
signal health_changed(current_health: int, maximum_health: int)
signal mana_changed(current_mana: int, maximum_mana: int)
signal attack_registered(weapon: SkillSystem.WeaponType)
signal gold_changed(new_gold: int)
signal attack_requested

@export_category("Movement")
@export var move_speed: float = 140.0

@export_category("Attributes")
@export var max_health: int = 100
@export var max_mana: int = 50

var health: int
var mana: int
var gold: int = 0
var joystick_vector: Vector2 = Vector2.ZERO
var is_dead: bool = false

@onready var skill_system: SkillSystem = $SkillSystem


func _ready() -> void:
    health = max_health
    mana = max_mana
    health_changed.emit(health, max_health)
    mana_changed.emit(mana, max_mana)


func _physics_process(_delta: float) -> void:
    if is_dead:
        velocity = Vector2.ZERO
        return

    var keyboard_vector := Vector2.ZERO
    if InputMap.has_action("move_left") and InputMap.has_action("move_right") \
            and InputMap.has_action("move_up") and InputMap.has_action("move_down"):
        keyboard_vector = Input.get_vector("move_left", "move_right", "move_up", "move_down")
    var movement_vector := keyboard_vector
    if movement_vector == Vector2.ZERO:
        movement_vector = joystick_vector

    movement_vector = movement_vector.limit_length(1.0)
    velocity = movement_vector * move_speed
    move_and_slide()


func set_joystick_vector(value: Vector2) -> void:
    joystick_vector = value.limit_length(1.0)


func clear_joystick() -> void:
    joystick_vector = Vector2.ZERO


func take_damage(amount: int) -> void:
    if is_dead or amount <= 0:
        return

    health = maxi(health - amount, 0)
    skill_system.register_damage_received(amount)
    health_changed.emit(health, max_health)

    if health == 0:
        die()


func heal(amount: int) -> void:
    if is_dead or amount <= 0:
        return

    health = mini(health + amount, max_health)
    health_changed.emit(health, max_health)


func add_gold(amount: int) -> void:
    if amount <= 0:
        return

    gold += amount
    gold_changed.emit(gold)


func spend_gold(amount: int) -> bool:
    if amount <= 0 or amount > gold:
        return false

    gold -= amount
    gold_changed.emit(gold)
    return true


## Cambia rápidamente entre Cuerpo a cuerpo, Arco y Báculo.
func cycle_weapon() -> SkillSystem.WeaponType:
    return skill_system.cycle_weapon()


## Selección directa útil para botones de inventario o hotbar.
func equip_weapon(weapon: SkillSystem.WeaponType) -> void:
    skill_system.set_weapon(weapon)


## Debe llamarse cuando el ataque conecta, no solamente al pulsar el botón.
## La XP se asigna automáticamente a Melee, Distancia o Magia.
func register_attack_hit(experience_amount: int = 10) -> void:
    skill_system.register_attack_hit(experience_amount)
    attack_registered.emit(skill_system.current_weapon)


## La UI llama esto; el sistema de combate decide si el ataque conecta.
func request_attack() -> void:
    if not is_dead:
        attack_requested.emit()


func die() -> void:
    if is_dead:
        return

    is_dead = true
    velocity = Vector2.ZERO
    died.emit()
