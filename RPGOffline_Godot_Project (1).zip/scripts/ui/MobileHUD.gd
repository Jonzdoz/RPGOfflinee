class_name MobileHUD
extends CanvasLayer

signal attack_button_pressed

@export var player_path: NodePath = NodePath("../Player")

var player: Player

@onready var joystick = $Root/VirtualJoystick
@onready var hp_bar: ProgressBar = $Root/TopLeft/HPBar
@onready var mp_bar: ProgressBar = $Root/TopLeft/MPBar
@onready var hp_label: Label = $Root/TopLeft/HPLabel
@onready var mp_label: Label = $Root/TopLeft/MPLabel
@onready var gold_label: Label = $Root/TopLeft/GoldLabel
@onready var melee_label: Label = $Root/StatsPanel/StatsBox/MeleeLabel
@onready var ranged_label: Label = $Root/StatsPanel/StatsBox/RangedLabel
@onready var magic_label: Label = $Root/StatsPanel/StatsBox/MagicLabel
@onready var defense_label: Label = $Root/StatsPanel/StatsBox/DefenseLabel
@onready var weapon_label: Label = $Root/ActionPanel/ActionBox/WeaponLabel


func _ready() -> void:
    player = get_node_or_null(player_path) as Player
    if not is_instance_valid(player):
        push_warning("MobileHUD: asigna player_path a una instancia de Player.")
        return

    joystick.vector_changed.connect(player.set_joystick_vector)
    joystick.released.connect(player.clear_joystick)

    $Root/ActionPanel/ActionBox/AttackButton.pressed.connect(_on_attack_button_pressed)
    $Root/ActionPanel/ActionBox/ClassButtons/MeleeButton.pressed.connect(_on_melee_pressed)
    $Root/ActionPanel/ActionBox/ClassButtons/RangedButton.pressed.connect(_on_ranged_pressed)
    $Root/ActionPanel/ActionBox/ClassButtons/MagicButton.pressed.connect(_on_magic_pressed)

    player.health_changed.connect(_on_health_changed)
    player.mana_changed.connect(_on_mana_changed)
    player.gold_changed.connect(_on_gold_changed)
    player.skill_system.skill_experience_changed.connect(_on_skill_experience_changed)
    player.skill_system.skill_level_up.connect(_on_skill_level_up)
    player.skill_system.weapon_changed.connect(_on_weapon_changed)

    _on_health_changed(player.health, player.max_health)
    _on_mana_changed(player.mana, player.max_mana)
    _on_gold_changed(player.gold)
    _refresh_all_skill_labels()
    _on_weapon_changed(player.skill_system.current_weapon)


func _on_attack_button_pressed() -> void:
    if not is_instance_valid(player) or player.is_dead:
        return

    # No concede XP aquí: solo solicita el ataque al sistema de combate.
    player.request_attack()
    attack_button_pressed.emit()


func _on_melee_pressed() -> void:
    if is_instance_valid(player):
        player.equip_weapon(SkillSystem.WeaponType.MELEE)


func _on_ranged_pressed() -> void:
    if is_instance_valid(player):
        player.equip_weapon(SkillSystem.WeaponType.BOW)


func _on_magic_pressed() -> void:
    if is_instance_valid(player):
        player.equip_weapon(SkillSystem.WeaponType.STAFF)


func _on_health_changed(current: int, maximum: int) -> void:
    hp_bar.max_value = maximum
    hp_bar.value = current
    hp_label.text = "HP %d / %d" % [current, maximum]


func _on_mana_changed(current: int, maximum: int) -> void:
    mp_bar.max_value = maximum
    mp_bar.value = current
    mp_label.text = "MP %d / %d" % [current, maximum]


func _on_gold_changed(new_gold: int) -> void:
    gold_label.text = "Oro: %d" % new_gold


func _on_skill_experience_changed(
        _skill: SkillSystem.SkillType,
        _current_xp: int,
        _xp_to_next_level: int
    ) -> void:
    _refresh_all_skill_labels()


func _on_skill_level_up(_skill: SkillSystem.SkillType, _new_level: int) -> void:
    _refresh_all_skill_labels()


func _refresh_all_skill_labels() -> void:
    if not is_instance_valid(player):
        return

    var skills: SkillSystem = player.skill_system
    melee_label.text = "Melee: Nv. %d" % skills.get_skill_level(SkillSystem.SkillType.MELEE)
    ranged_label.text = "Distancia: Nv. %d" % skills.get_skill_level(SkillSystem.SkillType.RANGED)
    magic_label.text = "Magia: Nv. %d" % skills.get_skill_level(SkillSystem.SkillType.MAGIC)
    defense_label.text = "Defensa: Nv. %d" % skills.get_skill_level(SkillSystem.SkillType.DEFENSE)


func _on_weapon_changed(new_weapon: SkillSystem.WeaponType) -> void:
    if is_instance_valid(player):
        weapon_label.text = "Arma: %s" % player.skill_system.get_weapon_name(new_weapon)
