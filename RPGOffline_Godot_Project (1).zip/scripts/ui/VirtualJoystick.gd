class_name MobileVirtualJoystick
extends Control

signal vector_changed(value: Vector2)
signal released

@export var knob_color: Color = Color(0.95, 0.95, 1.0, 0.85)
@export var base_color: Color = Color(0.15, 0.18, 0.25, 0.65)
@export var border_color: Color = Color(0.75, 0.82, 1.0, 0.8)

var output_vector: Vector2 = Vector2.ZERO
var knob_position: Vector2
var active_touch_id: int = -1
var mouse_is_active: bool = false


func _ready() -> void:
    mouse_filter = Control.MOUSE_FILTER_STOP
    knob_position = size / 2.0
    queue_redraw()


func _notification(what: int) -> void:
    if what == NOTIFICATION_RESIZED and not _is_dragging():
        knob_position = size / 2.0
        queue_redraw()


func _gui_input(event: InputEvent) -> void:
    if event is InputEventScreenTouch:
        if event.pressed and active_touch_id == -1:
            active_touch_id = event.index
            _update_from_position(event.position)
        elif not event.pressed and event.index == active_touch_id:
            active_touch_id = -1
            _reset_joystick()
        accept_event()
        return

    if event is InputEventScreenDrag and event.index == active_touch_id:
        _update_from_position(event.position)
        accept_event()
        return

    # Permite probar el joystick con el ratón en PC.
    if event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT:
        mouse_is_active = event.pressed
        if mouse_is_active:
            _update_from_position(event.position)
        else:
            _reset_joystick()
        accept_event()
    elif event is InputEventMouseMotion and mouse_is_active:
        _update_from_position(event.position)
        accept_event()


func _update_from_position(local_position: Vector2) -> void:
    var center := size / 2.0
    var radius := minf(size.x, size.y) * 0.36
    if radius <= 0.0:
        return

    output_vector = ((local_position - center) / radius).limit_length(1.0)
    knob_position = center + output_vector * radius
    vector_changed.emit(output_vector)
    queue_redraw()


func _reset_joystick() -> void:
    output_vector = Vector2.ZERO
    knob_position = size / 2.0
    released.emit()
    vector_changed.emit(Vector2.ZERO)
    queue_redraw()


func _is_dragging() -> bool:
    return active_touch_id != -1 or mouse_is_active


func _draw() -> void:
    var center := size / 2.0
    var base_radius := minf(size.x, size.y) * 0.42
    var knob_radius := minf(size.x, size.y) * 0.18

    draw_circle(center, base_radius, base_color)
    draw_arc(center, base_radius, 0.0, TAU, 48, border_color, 3.0, true)
    draw_circle(knob_position, knob_radius, knob_color)
