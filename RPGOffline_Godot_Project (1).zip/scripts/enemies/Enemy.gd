class_name Enemy
extends CharacterBody2D

signal health_changed(current_health: int, maximum_health: int)
signal died(enemy: Enemy)
signal loot_dropped(loot_type: StringName, amount: int, world_position: Vector2)

## Estados básicos de la IA.
enum EnemyState {
    IDLE,
    PATROL,
    CHASE,
    ATTACK,
    DEAD,
}

@export_category("Movement")
@export var move_speed: float = 55.0
@export var patrol_points: Array[Vector2] = []
@export var patrol_wait_time: float = 1.5

@export_category("Detection and Combat")
@export var attack_damage: int = 8
@export var attack_cooldown: float = 1.0

@export_category("Health")
@export var max_health: int = 40

@export_category("Rewards")
@export var experience_reward: int = 25
@export var gold_reward_min: int = 5
@export var gold_reward_max: int = 15
@export_range(0.0, 1.0, 0.05) var potion_drop_chance: float = 0.20

var health: int
var state: EnemyState = EnemyState.IDLE
var target: Player
var last_attacker: Player
var patrol_index: int = 0
var patrol_wait_remaining: float = 0.0
var is_dead: bool = false

@onready var detection_area: Area2D = $DetectionArea
@onready var attack_area: Area2D = $AttackArea
@onready var attack_timer: Timer = $AttackTimer


func _ready() -> void:
    health = max_health
    health_changed.emit(health, max_health)

    detection_area.body_entered.connect(_on_detection_body_entered)
    detection_area.body_exited.connect(_on_detection_body_exited)
    attack_timer.wait_time = attack_cooldown

    if patrol_points.is_empty():
        state = EnemyState.IDLE
    else:
        state = EnemyState.PATROL


func _physics_process(delta: float) -> void:
    if is_dead:
        return

    if not is_instance_valid(target):
        target = null

    if is_instance_valid(target):
        if _is_target_in_attack_range():
            _change_state(EnemyState.ATTACK)
        else:
            _change_state(EnemyState.CHASE)

    match state:
        EnemyState.IDLE:
            _process_idle()
        EnemyState.PATROL:
            _process_patrol(delta)
        EnemyState.CHASE:
            _process_chase()
        EnemyState.ATTACK:
            _process_attack()
        EnemyState.DEAD:
            velocity = Vector2.ZERO


func _process_idle() -> void:
    velocity = Vector2.ZERO


func _process_patrol(delta: float) -> void:
    if patrol_points.is_empty():
        _change_state(EnemyState.IDLE)
        return

    if patrol_wait_remaining > 0.0:
        patrol_wait_remaining -= delta
        velocity = Vector2.ZERO
        return

    var patrol_target: Vector2 = to_global(patrol_points[patrol_index])
    if global_position.distance_to(patrol_target) <= 4.0:
        patrol_index = (patrol_index + 1) % patrol_points.size()
        patrol_wait_remaining = patrol_wait_time
        velocity = Vector2.ZERO
        return

    velocity = global_position.direction_to(patrol_target) * move_speed
    move_and_slide()


func _process_chase() -> void:
    if not is_instance_valid(target):
        _change_state(EnemyState.IDLE if patrol_points.is_empty() else EnemyState.PATROL)
        velocity = Vector2.ZERO
        return

    velocity = global_position.direction_to(target.global_position) * move_speed
    move_and_slide()


func _process_attack() -> void:
    velocity = Vector2.ZERO
    if not is_instance_valid(target):
        return

    if not _is_target_in_attack_range():
        _change_state(EnemyState.CHASE)
        return

    if attack_timer.is_stopped():
        attack_timer.start()
        target.take_damage(attack_damage)


func _is_target_in_attack_range() -> bool:
    if not is_instance_valid(target):
        return false
    return attack_area.get_overlapping_bodies().has(target)


func _on_detection_body_entered(body: Node2D) -> void:
    if body is Player and not is_dead:
        target = body
        _change_state(EnemyState.CHASE)


func _on_detection_body_exited(body: Node2D) -> void:
    if body == target:
        target = null
        if not is_dead:
            _change_state(EnemyState.IDLE if patrol_points.is_empty() else EnemyState.PATROL)


func _change_state(new_state: EnemyState) -> void:
    if state == new_state:
        return
    state = new_state


## El jugador puede llamar esta función cuando su ataque conecta.
func take_damage(amount: int, attacker: Player = null) -> void:
    if is_dead or amount <= 0:
        return

    if is_instance_valid(attacker):
        last_attacker = attacker

    health = maxi(health - amount, 0)
    health_changed.emit(health, max_health)

    if health == 0:
        die()


func die() -> void:
    if is_dead:
        return

    is_dead = true
    state = EnemyState.DEAD
    velocity = Vector2.ZERO

    # Evita que el cadáver siga detectando o bloqueando al jugador.
    $CollisionShape2D.set_deferred("disabled", true)
    detection_area.set_deferred("monitoring", false)
    attack_area.set_deferred("monitoring", false)

    _grant_experience_reward()
    _drop_basic_loot()
    died.emit(self)
    queue_free()


func _grant_experience_reward() -> void:
    if not is_instance_valid(last_attacker) or experience_reward <= 0:
        return

    var skill_system: SkillSystem = last_attacker.skill_system
    var attack_skill: SkillSystem.SkillType = skill_system.get_attack_skill_for_weapon()
    skill_system.add_experience(attack_skill, experience_reward)


func _drop_basic_loot() -> void:
    var loot_type: StringName
    var amount: int

    if randf() < potion_drop_chance:
        loot_type = &"potion"
        amount = 1
    else:
        loot_type = &"gold"
        amount = randi_range(gold_reward_min, gold_reward_max)

    loot_dropped.emit(loot_type, amount, global_position)
