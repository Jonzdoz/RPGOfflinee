class_name SaveManagerClass
extends Node

const SAVE_PATH: String = "user://player_save.save"

var current_player: Player
var last_error: String = ""


## Registra el jugador que debe serializarse en el autoguardado.
func register_player(player: Player) -> void:
    current_player = player


## Guarda el estado actual del jugador en JSON dentro de user://.
func save_game(player: Player = current_player) -> bool:
    last_error = ""
    if not is_instance_valid(player):
        last_error = "No hay un Player válido para guardar."
        return false

    var save_data: Dictionary = {
        "version": 1,
        "player": {
            "position": {
                "x": player.global_position.x,
                "y": player.global_position.y,
            },
            "health": {
                "current": player.health,
                "maximum": player.max_health,
            },
            "gold": player.gold,
            "skills": player.skill_system.get_save_data(),
        },
    }

    var file := FileAccess.open(SAVE_PATH, FileAccess.WRITE)
    if file == null:
        last_error = "No se pudo abrir el archivo: %s" % error_string(FileAccess.get_open_error())
        return false

    file.store_string(JSON.stringify(save_data, "\t"))
    file.close()
    return true


## Carga el archivo si existe y restaura posición, salud, oro y habilidades.
func load_game(player: Player = current_player) -> bool:
    last_error = ""
    if not is_instance_valid(player):
        last_error = "No hay un Player válido para cargar."
        return false

    if not FileAccess.file_exists(SAVE_PATH):
        return false

    var file := FileAccess.open(SAVE_PATH, FileAccess.READ)
    if file == null:
        last_error = "No se pudo leer el archivo de guardado."
        return false

    var parsed: Variant = JSON.parse_string(file.get_as_text())
    file.close()

    if not parsed is Dictionary:
        last_error = "El archivo de guardado no contiene un objeto JSON válido."
        return false

    var root_data: Dictionary = parsed
    var raw_player_data: Variant = root_data.get("player", {})
    if not raw_player_data is Dictionary:
        last_error = "El campo player del guardado no es válido."
        return false

    var player_data: Dictionary = raw_player_data
    if player_data.is_empty():
        last_error = "El archivo no contiene datos del jugador."
        return false

    var raw_position_data: Variant = player_data.get("position", {})
    if not raw_position_data is Dictionary:
        last_error = "La posición guardada no es válida."
        return false

    var position_data: Dictionary = raw_position_data
    if not position_data.is_empty():
        player.global_position = Vector2(
            float(position_data.get("x", player.global_position.x)),
            float(position_data.get("y", player.global_position.y))
        )

    var raw_health_data: Variant = player_data.get("health", {})
    if not raw_health_data is Dictionary:
        last_error = "Los datos de salud guardados no son válidos."
        return false

    var health_data: Dictionary = raw_health_data
    if not health_data.is_empty():
        player.max_health = maxi(int(health_data.get("maximum", player.max_health)), 1)
        player.health = clampi(
            int(health_data.get("current", player.health)),
            0,
            player.max_health
        )
        player.health_changed.emit(player.health, player.max_health)

    player.gold = maxi(int(player_data.get("gold", player.gold)), 0)
    player.gold_changed.emit(player.gold)

    var raw_skills_data: Variant = player_data.get("skills", {})
    if not raw_skills_data is Dictionary:
        last_error = "Los datos de habilidades guardados no son válidos."
        return false

    var skills_data: Dictionary = raw_skills_data
    player.skill_system.load_save_data(skills_data)
    return true


## Borra el archivo local. Úsalo solo desde un menú de borrar partida.
func delete_save() -> bool:
    if not FileAccess.file_exists(SAVE_PATH):
        return true
    return DirAccess.remove_absolute(ProjectSettings.globalize_path(SAVE_PATH)) == OK


func has_save() -> bool:
    return FileAccess.file_exists(SAVE_PATH)


func _notification(what: int) -> void:
    if what == NOTIFICATION_WM_CLOSE_REQUEST:
        save_game()
        get_tree().quit()
    elif what == NOTIFICATION_APPLICATION_PAUSED:
        # Importante para Android: guarda cuando el sistema suspende la aplicación.
        save_game()
