class_name Main
extends Node2D

const ENEMY_SCENE: PackedScene = preload("res://scenes/enemies/Enemy.tscn")

@export var player_attack_range: float = 90.0
@export var player_attack_damage: int = 12
@export var player_attack_xp: int = 10

@onready var player: Player = $Player
@onready var enemies_root: Node2D = $Enemies
@onready var hud: MobileHUD = $MobileHUD

var save_was_loaded: bool = false


func _ready() -> void:
    _ensure_default_input_actions()

    # Main es el único punto que carga la partida para evitar cargarla dos veces.
    SaveManager.register_player(player)
    save_was_loaded = SaveManager.load_game(player)
    if save_was_loaded:
        print("Partida cargada desde ", SaveManager.SAVE_PATH)
    else:
        print("Nueva partida o guardado inexistente")

    player.attack_requested.connect(_on_player_attack_requested)
    player.died.connect(_on_player_died)
    hud.attack_button_pressed.connect(_on_attack_button_pressed)

    for enemy_node in enemies_root.get_children():
        if enemy_node is Enemy:
            _register_enemy(enemy_node)


## Busca el enemigo vivo más cercano dentro del alcance del ataque.
func find_enemy_in_attack_range() -> Enemy:
    var closest_enemy: Enemy
    var closest_distance := player_attack_range

    for enemy_node in enemies_root.get_children():
        if not enemy_node is Enemy:
            continue

        var enemy: Enemy = enemy_node
        if enemy.is_dead:
            continue

        var distance := player.global_position.distance_to(enemy.global_position)
        if distance <= closest_distance:
            closest_distance = distance
            closest_enemy = enemy

    return closest_enemy


## La UI solicita el ataque; Main decide si existe un objetivo válido.
func _on_player_attack_requested() -> void:
    var target := find_enemy_in_attack_range()
    if target == null:
        print("No hay un enemigo dentro del alcance")
        return

    target.take_damage(player_attack_damage, player)
    # XP por golpe conectado. Enemy añade el bonus por muerte si corresponde.
    player.register_attack_hit(player_attack_xp)


func _on_attack_button_pressed() -> void:
    # Punto de extensión para sonido, animación o vibración.
    pass


func _register_enemy(enemy: Enemy) -> void:
    enemy.loot_dropped.connect(_on_enemy_loot_dropped)
    enemy.died.connect(_on_enemy_died)


func _on_enemy_loot_dropped(
        loot_type: StringName,
        amount: int,
        world_position: Vector2
    ) -> void:
    if loot_type == &"gold":
        player.add_gold(amount)
        print("Oro recogible generado: ", amount, " en ", world_position)
    elif loot_type == &"potion":
        # Implementación mínima: la poción se recoge inmediatamente.
        # Sustituir por PotionDrop.tscn cuando exista inventario visual.
        player.heal(amount * 20)
        print("Poción generada en ", world_position)


func _on_enemy_died(_enemy: Enemy) -> void:
    SaveManager.save_game(player)


func _on_player_died() -> void:
    SaveManager.save_game(player)
    print("Jugador muerto: partida guardada antes de mostrar la pantalla de derrota")


## Permite que el proyecto funcione recién clonado incluso antes de configurar Input Map.
func _ensure_default_input_actions() -> void:
    var default_keys := {
        "move_up": KEY_W,
        "move_down": KEY_S,
        "move_left": KEY_A,
        "move_right": KEY_D,
    }

    for action_name in default_keys:
        if not InputMap.has_action(action_name):
            InputMap.add_action(action_name)

        if InputMap.action_get_events(action_name).is_empty():
            var key_event := InputEventKey.new()
            key_event.physical_keycode = default_keys[action_name]
            InputMap.action_add_event(action_name, key_event)
