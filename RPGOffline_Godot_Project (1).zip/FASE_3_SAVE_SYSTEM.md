# Fase 3 — Sistema de guardado local offline

Esta fase añade un sistema de guardado local para Android y PC usando un archivo JSON en:

```text
user://player_save.save
```

La ruta `user://` es administrada por Godot y apunta a una carpeta escribible del dispositivo. No se necesita servidor, cuenta, internet ni base de datos.

## 1. Qué se guarda

El archivo contiene:

- Nivel y experiencia de **Melee**.
- Nivel y experiencia de **Distancia**.
- Nivel y experiencia de **Magia**.
- Nivel y experiencia de **Defensa**.
- Posición actual del jugador: `x` e `y`.
- Salud actual y salud máxima.
- Oro acumulado.
- Arma activa, como dato adicional útil para restaurar la sesión.

## 2. Archivos añadidos y modificados

Nuevo gestor:

```text
res://scripts/save/SaveManager.gd
```

Archivos integrados:

```text
res://scripts/player/Player.gd
res://scripts/player/SkillSystem.gd
res://scenes/player/Player.tscn
res://project.godot
```

`project.godot` ya contiene el autoload:

```ini
[autoload]
SaveManager="*res://scripts/save/SaveManager.gd"
```

El autoload hace que `SaveManager` esté disponible desde cualquier escena:

```gdscript
SaveManager.save_game($Player)
SaveManager.load_game($Player)
```

## 3. Flujo automático

`Player.gd` registra y carga el jugador en `_ready()`:

```gdscript
func _ready() -> void:
    health = max_health
    mana = max_mana
    health_changed.emit(health, max_health)
    mana_changed.emit(mana, max_mana)
    SaveManager.register_player(self)
    SaveManager.load_game(self)
```

Si todavía no existe `user://player_save.save`, `load_game()` devuelve `false` y el jugador conserva los valores iniciales del Inspector.

`SaveManager.gd` guarda automáticamente cuando:

- Godot recibe `NOTIFICATION_WM_CLOSE_REQUEST` al cerrar el juego.
- Android pausa o suspende la aplicación mediante `NOTIFICATION_APPLICATION_PAUSED`.

El guardado ocurre antes de que el árbol se cierre en PC:

```gdscript
func _notification(what: int) -> void:
    if what == NOTIFICATION_WM_CLOSE_REQUEST:
        save_game()
        get_tree().quit()
    elif what == NOTIFICATION_APPLICATION_PAUSED:
        save_game()
```

> El autoguardado no debe ser la única protección contra cierres forzados del sistema. Para un juego real conviene guardar también en hitos importantes, como cambio de mapa, compra, recompensa o zona de guardado.

## 4. Guardado manual desde un botón

Crea una UI similar a:

```text
CanvasLayer
└── HUD
    └── SaveButton (Button)
```

Conecta la señal `pressed` de `SaveButton` a un controlador:

```gdscript
func _on_save_button_pressed() -> void:
    if SaveManager.save_game($Player):
        $CanvasLayer/HUD/SaveMessage.text = "Partida guardada"
    else:
        $CanvasLayer/HUD/SaveMessage.text = "Error: " + SaveManager.last_error
```

Si el script está en el propio HUD y el jugador está fuera de esa ruta, usa una referencia exportada:

```gdscript
@export var player: Player

func _on_save_button_pressed() -> void:
    if is_instance_valid(player) and SaveManager.save_game(player):
        print("Guardado correcto en ", SaveManager.SAVE_PATH)
```

## 5. Zona de guardado

Crea una zona con este árbol:

```text
SaveZone (Area2D)
├── CollisionShape2D
└── Sprite2D                  [opcional]
```

En el script de `SaveZone`, conecta `body_entered`:

```gdscript
extends Area2D

func _on_body_entered(body: Node2D) -> void:
    if body is Player:
        if SaveManager.save_game(body):
            print("Zona de guardado activada")
```

Para evitar guardar muchas veces mientras el jugador permanece dentro, usa una bandera:

```gdscript
extends Area2D

var player_inside: bool = false

func _on_body_entered(body: Node2D) -> void:
    if body is Player and not player_inside:
        player_inside = true
        SaveManager.save_game(body)

func _on_body_exited(body: Node2D) -> void:
    if body is Player:
        player_inside = false
```

## 6. Integración con `SkillSystem.gd`

`SkillSystem` convierte sus enums en nombres estables antes de serializar. Esto evita depender de claves numéricas que podrían cambiar si se reordena un enum:

```gdscript
func get_save_data() -> Dictionary:
    return {
        "melee": {
            "level": get_skill_level(SkillType.MELEE),
            "experience": get_skill_experience(SkillType.MELEE),
        },
        "ranged": {
            "level": get_skill_level(SkillType.RANGED),
            "experience": get_skill_experience(SkillType.RANGED),
        },
        "magic": {
            "level": get_skill_level(SkillType.MAGIC),
            "experience": get_skill_experience(SkillType.MAGIC),
        },
        "defense": {
            "level": get_skill_level(SkillType.DEFENSE),
            "experience": get_skill_experience(SkillType.DEFENSE),
        },
    }
```

Al cargar, `SaveManager` delega la restauración:

```gdscript
player.skill_system.load_save_data(skills_data)
```

Esto mantiene la responsabilidad separada:

- `SaveManager`: archivo, JSON y errores de lectura/escritura.
- `Player`: posición, salud y oro.
- `SkillSystem`: niveles y experiencia.

## 7. Integración con `Player.gd`

`Player.gd` tiene las propiedades necesarias:

```gdscript
var health: int
var gold: int = 0
@onready var skill_system: SkillSystem = $SkillSystem
```

También emite cambios de oro para actualizar el HUD:

```gdscript
func add_gold(amount: int) -> void:
    if amount <= 0:
        return

    gold += amount
    gold_changed.emit(gold)
```

Al recibir daño, la Fase 2 sigue entrenando Defensa y la Fase 3 captura el estado actualizado cuando se guarda:

```gdscript
func take_damage(amount: int) -> void:
    if is_dead or amount <= 0:
        return

    health = maxi(health - amount, 0)
    skill_system.register_damage_received(amount)
    health_changed.emit(health, max_health)

    if health == 0:
        die()
```

## 8. Formato aproximado del JSON

El archivo generado tendrá una estructura parecida a esta:

```json
{
    "version": 1,
    "player": {
        "position": {
            "x": 320.0,
            "y": 180.0
        },
        "health": {
            "current": 76,
            "maximum": 100
        },
        "gold": 245,
        "skills": {
            "melee": {
                "level": 4,
                "experience": 443
            },
            "ranged": {
                "level": 2,
                "experience": 120
            },
            "magic": {
                "level": 1,
                "experience": 0
            },
            "defense": {
                "level": 3,
                "experience": 270
            },
            "weapon": 0
        }
    }
}
```

`weapon` es un dato adicional: `0` corresponde a cuerpo a cuerpo, `1` a arco y `2` a báculo.

## 9. Cargar y guardar desde un controlador principal

Una forma explícita de controlar el flujo de una escena principal es:

```gdscript
extends Node2D

@onready var player: Player = $Player

func _ready() -> void:
    var loaded := SaveManager.load_game(player)
    if loaded:
        print("Partida restaurada")
    else:
        print("Partida nueva o sin archivo de guardado")

func save_checkpoint() -> void:
    if not SaveManager.save_game(player):
        push_error(SaveManager.last_error)
```

En este caso, evita cargar dos veces si `Player._ready()` ya llama a `load_game()`. Elige una sola estrategia:

- **Recomendada para esta fase:** dejar la carga automática en `Player._ready()`.
- **Alternativa:** quitar esa llamada de `Player.gd` y cargar desde `Main.gd` cuando la escena esté lista.

## 10. Borrar una partida local

El gestor incluye una función para el menú de nueva partida:

```gdscript
func _on_delete_save_pressed() -> void:
    if SaveManager.delete_save():
        print("Partida eliminada")
```

Esta acción es destructiva. Debe estar detrás de una pantalla de confirmación dentro del juego, por ejemplo: `¿Borrar todos los datos locales?`.

## 11. Prueba paso a paso

1. Ejecuta el proyecto una primera vez.
2. Comprueba que `Player` empieza con nivel 1, XP 0, salud inicial y oro 0.
3. Mueve al jugador hasta una posición reconocible.
4. Ejecuta:

   ```gdscript
   $Player.add_gold(100)
   $Player.register_attack_hit(100)
   $Player.take_damage(10)
   SaveManager.save_game($Player)
   ```

5. Cierra el juego normalmente.
6. Vuelve a ejecutarlo.
7. Verifica que posición, oro, vida, Melee y Defensa se restauraron.
8. Cambia a arco o báculo, gana XP, guarda y confirma que el arma activa también se conserva.
9. Prueba un botón y una `SaveZone`.
10. Prueba Android suspendiendo y reanudando la aplicación.

## 12. Lista de verificación

- [ ] `SaveManager.gd` está en `res://scripts/save/SaveManager.gd`.
- [ ] El autoload `SaveManager` está configurado en `project.godot`.
- [ ] Se usa `user://player_save.save`, no una ruta absoluta del PC.
- [ ] Se guardan las cuatro habilidades con nivel y experiencia.
- [ ] Se guarda posición `x`/`y`.
- [ ] Se guarda salud actual y máxima.
- [ ] Se guarda oro.
- [ ] Cerrar o pausar la aplicación activa el autoguardado.
- [ ] Un botón y una zona pueden llamar a `save_game()`.
- [ ] `load_game()` se ejecuta al entrar a la escena del jugador.
- [ ] El archivo corrupto produce un error controlado y no rompe el juego.
- [ ] La eliminación de la partida exige confirmación dentro del juego.
