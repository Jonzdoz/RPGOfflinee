# Fase 4 — Enemigos e inteligencia artificial básica

Esta fase añade un enemigo 2D basado en `CharacterBody2D` con una máquina de estados sencilla:

```text
IDLE/REPOSO <-> PATROL/PATRULLA
       ^             |
       |             v
   CHASE/PERSECUCIÓN -> ATTACK/ATAQUE
              \
               -> DEAD/MUERTO
```

El enemigo detecta al jugador mediante un `Area2D`, lo persigue, ataca cuando entra en el área de ataque, recibe daño, muere, otorga XP de combate y emite un botín básico.

## 1. Archivos y estructura de `Enemy.tscn`

Archivos:

```text
res://scripts/enemies/Enemy.gd
res://scenes/enemies/Enemy.tscn
```

Árbol de nodos creado:

```text
Enemy (CharacterBody2D)
├── CollisionShape2D              # cuerpo físico
├── DetectionArea (Area2D)        # radio de persecución
│   └── CollisionShape2D
├── AttackArea (Area2D)           # distancia de ataque
│   └── CollisionShape2D
├── AttackTimer (Timer)            # cadencia de ataque
└── Sprite2D                       # opcional/placeholder
```

### Configuración de colisiones

- `Enemy/CollisionShape2D`: forma física del enemigo.
- `DetectionArea.collision_layer = 0`: el área no es un obstáculo.
- `DetectionArea.collision_mask = 1`: detecta cuerpos de la capa 1, donde está el jugador de la Fase 1.
- `AttackArea.collision_layer = 0` y `collision_mask = 1`.
- El jugador debe tener un `CollisionShape2D` y estar en `Collision Layer 1`.

El radio por defecto de detección es `180` píxeles y el de ataque `28` píxeles. Puedes modificarlos desde el Inspector cambiando las formas de los `CollisionShape2D`.

## 2. Estados de la IA

El script `Enemy.gd` utiliza el enum:

```gdscript
enum EnemyState {
    IDLE,
    PATROL,
    CHASE,
    ATTACK,
    DEAD,
}
```

### Reposo

Si `patrol_points` está vacío, el enemigo permanece quieto hasta detectar al jugador.

### Patrullaje

Desde el Inspector puedes asignar puntos locales:

```gdscript
patrol_points = [Vector2(-80, 0), Vector2(80, 0)]
```

El enemigo se mueve entre ellos y espera `patrol_wait_time` segundos en cada punto. Si el jugador entra en `DetectionArea`, la patrulla se interrumpe.

### Persecución

Cuando el cuerpo del jugador entra en `DetectionArea`, el script recibe `body_entered`, guarda la referencia y mueve el enemigo hacia `target.global_position`.

Al salir de `DetectionArea`, el enemigo vuelve a reposo o patrullaje.

### Ataque

Cuando el jugador está dentro de `AttackArea`, el enemigo detiene su movimiento y llama:

```gdscript
target.take_damage(attack_damage)
```

`AttackTimer` limita la frecuencia para que el enemigo no aplique daño en cada frame.

## 3. Salud y daño del enemigo

El enemigo expone en el Inspector:

```gdscript
@export var max_health: int = 40
@export var attack_damage: int = 8
```

Para que el jugador le haga daño:

```gdscript
var enemy: Enemy = $Enemy
enemy.take_damage(15, $Player)
```

El segundo parámetro registra quién fue el último atacante. Esto permite otorgar la XP al jugador correcto cuando muere el enemigo.

Si solo existe un jugador, también puedes conservar la referencia en el controlador de combate:

```gdscript
func resolve_player_attack(enemy: Enemy, player: Player, damage: int) -> void:
    enemy.take_damage(damage, player)
```

## 4. XP al morir

Al morir, `Enemy.gd` busca el arma activa del último atacante:

```gdscript
var skill_system: SkillSystem = last_attacker.skill_system
var attack_skill: SkillSystem.SkillType = skill_system.get_attack_skill_for_weapon()
skill_system.add_experience(attack_skill, experience_reward)
```

La recompensa predeterminada es `25 XP`. Por tanto:

- cuerpo a cuerpo concede XP a **Melee**;
- arco concede XP a **Distancia**;
- báculo concede XP a **Magia**.

Esta recompensa es un **bonus por matar** y se suma a la XP por golpe de la Fase 2. Si prefieres que la muerte no dé bonus adicional, establece `experience_reward = 0` en el Inspector.

## 5. Botín básico

El enemigo decide aleatoriamente entre oro y poción usando:

```gdscript
@export var gold_reward_min: int = 5
@export var gold_reward_max: int = 15
@export var potion_drop_chance: float = 0.20
```

Después emite:

```gdscript
signal loot_dropped(
    loot_type: StringName,
    amount: int,
    world_position: Vector2
)
```

El enemigo no conoce la UI ni el inventario. El mapa o un `LootManager` recibe la señal y crea la escena visual apropiada.

### Conectar el botín desde la escena principal

```gdscript
func _ready() -> void:
    var enemy: Enemy = $Enemy
    enemy.loot_dropped.connect(_on_enemy_loot_dropped)

func _on_enemy_loot_dropped(
        loot_type: StringName,
        amount: int,
        world_position: Vector2
    ) -> void:
    if loot_type == &"gold":
        print("Soltar moneda: ", amount, " en ", world_position)
        # Instanciar aquí GoldDrop.tscn.
    elif loot_type == &"potion":
        print("Soltar poción en ", world_position)
        # Instanciar aquí PotionDrop.tscn.
```

### Recoger directamente el oro, sin objeto visual

Para una prueba rápida, el receptor puede dar el oro al jugador inmediatamente:

```gdscript
func _on_enemy_loot_dropped(
        loot_type: StringName,
        amount: int,
        world_position: Vector2
    ) -> void:
    if loot_type == &"gold":
        $Player.add_gold(amount)
    else:
        print("La poción queda en: ", world_position)
```

Para un juego definitivo, es preferible crear una entidad de loot con `Area2D`, animación y recogida por proximidad.

## 6. Crear una instancia en el mapa

1. Abre `Main.tscn`.
2. Arrastra `res://scenes/enemies/Enemy.tscn` al mapa.
3. Asegúrate de que el jugador esté en la capa de colisión 1.
4. En el Inspector del enemigo, configura:
   - `max_health`.
   - `attack_damage`.
   - `move_speed`.
   - `experience_reward`.
   - `patrol_points`, si quieres patrullaje.
5. Conecta `loot_dropped` al controlador del mapa.
6. Prueba entrando y saliendo del círculo de detección.

Para configurar puntos de patrulla desde código:

```gdscript
var enemy: Enemy = preload("res://scenes/enemies/Enemy.tscn").instantiate()
enemy.patrol_points = [Vector2(-100, 0), Vector2(100, 0)]
enemy.global_position = Vector2(400, 200)
add_child(enemy)
enemy.loot_dropped.connect(_on_enemy_loot_dropped)
```

## 7. Flujo de combate completo

```gdscript
func player_attack(enemy: Enemy, player: Player) -> void:
    if enemy.is_dead:
        return

    var damage := 12
    enemy.take_damage(damage, player)

    # XP por golpe conectado de la Fase 2.
    player.register_attack_hit(10)

    # Si este golpe deja al enemigo en 0 HP, Enemy.die() añade además
    # experience_reward como bonus de muerte.
```

El ataque debe llamar a `take_damage()` solo si realmente conectó. Un ataque fallido no debe registrar daño, XP ni cambiar el último atacante.

## 8. Comportamiento al morir

`die()` realiza estas acciones una sola vez:

1. Cambia el estado a `DEAD`.
2. Detiene el movimiento.
3. Deshabilita la colisión física.
4. Desactiva las áreas de detección y ataque.
5. Otorga XP al último jugador atacante.
6. Emite `loot_dropped`.
7. Emite `died`.
8. Libera el nodo con `queue_free()`.

La señal `died` puede usarse para un contador de enemigos:

```gdscript
func _on_enemy_died(enemy: Enemy) -> void:
    enemies_alive -= 1
```

## 9. Consideraciones para la siguiente iteración

Esta IA es intencionalmente básica. Más adelante se puede añadir:

- navegación con `NavigationAgent2D`;
- línea de visión y obstáculos;
- animaciones según estado;
- varios tipos de ataque;
- retorno al punto inicial si se aleja demasiado;
- agresividad, rango de abandono y grupos de enemigos;
- tablas de loot y objetos persistentes.

## 10. Lista de verificación

- [ ] El enemigo usa `CharacterBody2D`.
- [ ] `DetectionArea` detecta al jugador al entrar.
- [ ] El enemigo vuelve a reposo o patrulla al perderlo.
- [ ] `AttackArea` limita la distancia de ataque.
- [ ] `AttackTimer` limita los golpes repetidos.
- [ ] `take_damage()` reduce salud y registra al atacante.
- [ ] `die()` solo se ejecuta una vez.
- [ ] La muerte concede XP a la habilidad del arma activa.
- [ ] La muerte emite oro o poción mediante `loot_dropped`.
- [ ] Las áreas y colisiones se desactivan al morir.
