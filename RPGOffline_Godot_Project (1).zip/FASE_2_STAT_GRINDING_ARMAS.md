# Fase 2 — Entrenar habilidades y cambio de clase/arma

Esta fase agrega un sistema de progreso estilo RPG con cuatro estadísticas independientes:

- **Melee**: se entrena al conectar ataques de cuerpo a cuerpo.
- **Distancia**: se entrena al conectar ataques con arco.
- **Magia**: se entrena al conectar ataques con báculo.
- **Defensa**: se entrena al recibir daño real.

El sistema está separado en un nodo `SkillSystem`, por lo que el progreso puede guardarse más adelante sin mezclarlo con el movimiento o la vida del jugador.

## 1. Archivos y árbol de nodos

Añade este script:

```text
res://scripts/player/SkillSystem.gd
```

La escena del jugador queda así:

```text
Player (CharacterBody2D)
├── CollisionShape2D
├── SkillSystem (Node)
└── Camera2D                 [opcional]
```

El archivo actualizado `Player.tscn` ya incluye el nodo `SkillSystem` y `Player.gd` ya contiene la integración.

## 2. Script `SkillSystem.gd`

El script completo está en `res://scripts/player/SkillSystem.gd`.

### Modelo de datos

Cada habilidad tiene sus propios valores:

```gdscript
skill_levels[SkillSystem.SkillType.MELEE] = 1
skill_experience[SkillSystem.SkillType.MELEE] = 0
```

Por tanto, subir **Melee** no sube **Distancia**, **Magia** ni **Defensa**.

La fórmula incluida es:

```text
XP total para nivel N = experience_base * (N - 1) ^ experience_growth
```

Con los valores por defecto (`100` y `1.35`):

| Nivel objetivo | XP total aproximada |
|---:|---:|
| 2 | 100 |
| 3 | 255 |
| 4 | 443 |
| 5 | 622 |

Puedes cambiar `experience_base` y `experience_growth` desde el Inspector del nodo `SkillSystem`.

## 3. Regla exacta de experiencia por golpe

La XP ofensiva se concede mediante:

```gdscript
player.register_attack_hit(10)
```

Debe llamarse **una sola vez cuando el ataque conecta**, después de validar alcance, línea de visión y colisión. No debe llamarse simplemente al pulsar el botón de ataque.

La habilidad que recibe XP se determina automáticamente:

| Arma activa | Habilidad entrenada |
|---|---|
| `WeaponType.MELEE` | Melee |
| `WeaponType.BOW` | Distancia |
| `WeaponType.STAFF` | Magia |

La defensa se entrena desde `Player.take_damage()`:

```gdscript
skill_system.register_damage_received(amount)
```

Así, cada daño recibido incrementa Defensa, incluso si el jugador sobrevive con poca vida.

## 4. Cambio rápido de arma

### Alternar en orden

```gdscript
$Player.cycle_weapon()
```

El ciclo es:

```text
Cuerpo a cuerpo -> Arco -> Báculo -> Cuerpo a cuerpo
```

### Seleccionar un arma directamente

```gdscript
$Player.equip_weapon(SkillSystem.WeaponType.MELEE)
$Player.equip_weapon(SkillSystem.WeaponType.BOW)
$Player.equip_weapon(SkillSystem.WeaponType.STAFF)
```

Esto es útil para una hotbar, botones táctiles o teclas rápidas.

Ejemplo con teclas temporales en un controlador:

```gdscript
func _unhandled_input(event: InputEvent) -> void:
    if event.is_action_pressed("switch_weapon"):
        $Player.cycle_weapon()
    elif event.is_action_pressed("weapon_melee"):
        $Player.equip_weapon(SkillSystem.WeaponType.MELEE)
    elif event.is_action_pressed("weapon_bow"):
        $Player.equip_weapon(SkillSystem.WeaponType.BOW)
    elif event.is_action_pressed("weapon_staff"):
        $Player.equip_weapon(SkillSystem.WeaponType.STAFF)
```

Crea esas acciones opcionales en **Project > Project Settings > Input Map** y asígnales, por ejemplo, `Tab`, `1`, `2` y `3`.

## 5. Integración con `Player.gd`

El jugador obtiene el nodo hijo con:

```gdscript
@onready var skill_system: SkillSystem = $SkillSystem
```

### Al recibir daño

La función de la Fase 1 fue ampliada así:

```gdscript
func take_damage(amount: int) -> void:
    if is_dead or amount <= 0:
        return

    health = maxi(health - amount, 0)
    skill_system.register_damage_received(amount)
    health_changed.emit(health, max_health)

    if health == 0:
        die()
```

No agregues XP de Defensa en el enemigo y en `Player.gd` al mismo tiempo: eso duplicaría el entrenamiento.

### Al conectar un ataque

`Player.gd` expone una función pequeña para que el sistema de combate no tenga que conocer los diccionarios internos:

```gdscript
func register_attack_hit(experience_amount: int = 10) -> void:
    skill_system.register_attack_hit(experience_amount)
    attack_registered.emit(skill_system.current_weapon)
```

Ejemplo en un sistema de combate:

```gdscript
func resolve_player_attack() -> void:
    var player: Player = $Player
    var target: Node2D = find_target_in_attack_range()

    if target == null:
        return

    var damage: int = calculate_damage(player.skill_system.get_attack_skill_for_weapon())
    target.take_damage(damage)

    # Solo aquí, porque el golpe sí conectó.
    player.register_attack_hit(10)
```

Un ataque que falla no concede XP. Si un ataque golpea a varios objetivos, decide una política y mantenla: puedes conceder XP una vez por acción o una vez por objetivo, pero no accidentalmente en ambos sitios.

## 6. Observar niveles y XP desde el HUD

El `SkillSystem` emite señales para actualizar barras y textos:

```gdscript
func _ready() -> void:
    var skills: SkillSystem = $Player/SkillSystem
    skills.skill_experience_changed.connect(_on_skill_experience_changed)
    skills.skill_level_up.connect(_on_skill_level_up)
    skills.weapon_changed.connect(_on_weapon_changed)

func _on_skill_experience_changed(
        skill: SkillSystem.SkillType,
        current_xp: int,
        xp_to_next_level: int
    ) -> void:
    print("%s: XP total %d, faltan %d" % [
        $Player/SkillSystem.get_skill_name(skill),
        current_xp,
        xp_to_next_level
    ])

func _on_skill_level_up(skill: SkillSystem.SkillType, new_level: int) -> void:
    print("Subió %s a nivel %d" % [
        $Player/SkillSystem.get_skill_name(skill),
        new_level
    ])

func _on_weapon_changed(new_weapon: SkillSystem.WeaponType) -> void:
    print("Arma equipada: %s" % $Player/SkillSystem.get_weapon_name(new_weapon))
```

Para una `ProgressBar`, puedes obtener el nivel y la XP de la habilidad:

```gdscript
var system: SkillSystem = $Player/SkillSystem
var skill := SkillSystem.SkillType.MELEE
var level := system.get_skill_level(skill)
var total_xp := system.get_skill_experience(skill)
var next_level_total := system.get_total_xp_for_level(level + 1)
var previous_level_total := system.get_total_xp_for_level(level)

progress_bar.max_value = next_level_total - previous_level_total
progress_bar.value = total_xp - previous_level_total
```

## 7. Flujo completo de ejemplo

```gdscript
# El jugador equipa un arco.
$Player.equip_weapon(SkillSystem.WeaponType.BOW)

# El ataque sale, encuentra un objetivo y aplica daño.
var target: Node2D = find_target_in_attack_range()
if target != null:
    target.take_damage(12)
    $Player.register_attack_hit(10) # Entrena Distancia.

# Más tarde, un enemigo golpea al jugador.
$Player.take_damage(8) # Entrena Defensa con 8 XP.

# El jugador cambia al báculo.
$Player.equip_weapon(SkillSystem.WeaponType.STAFF)
# El siguiente golpe conectado entrenará Magia.
```

## 8. Comprobación rápida sin sistema de combate

Puedes ejecutar este bloque desde un nodo de pruebas que tenga una instancia de `Player`:

```gdscript
func test_phase_2() -> void:
    var player: Player = $Player

    player.equip_weapon(SkillSystem.WeaponType.MELEE)
    player.register_attack_hit(100)
    print("Melee nivel: ", player.skill_system.get_skill_level(SkillSystem.SkillType.MELEE))

    player.equip_weapon(SkillSystem.WeaponType.BOW)
    player.register_attack_hit(100)
    print("Distancia nivel: ", player.skill_system.get_skill_level(SkillSystem.SkillType.RANGED))

    player.equip_weapon(SkillSystem.WeaponType.STAFF)
    player.register_attack_hit(100)
    print("Magia nivel: ", player.skill_system.get_skill_level(SkillSystem.SkillType.MAGIC))

    player.take_damage(25)
    print("Defensa XP: ", player.skill_system.get_skill_experience(SkillSystem.SkillType.DEFENSE))
```

Con 100 XP, cada habilidad ofensiva debería alcanzar nivel 2 de forma independiente y Defensa debería tener 25 XP.

## 9. Lista de verificación

- [ ] `SkillSystem.gd` está en `res://scripts/player/`.
- [ ] `Player.tscn` contiene un hijo llamado exactamente `SkillSystem`.
- [ ] Melee, Distancia, Magia y Defensa comienzan en nivel 1.
- [ ] Un golpe de cuerpo a cuerpo solo entrena Melee.
- [ ] Un golpe de arco solo entrena Distancia.
- [ ] Un golpe de báculo solo entrena Magia.
- [ ] Recibir daño entrena Defensa.
- [ ] Un ataque fallido no concede XP.
- [ ] `cycle_weapon()` alterna las tres armas.
- [ ] Las señales permiten actualizar el HUD.
- [ ] La validación de Godot no muestra errores de parseo.
