# Fase 6 — Escena principal e integración final

Esta fase reúne los componentes del proyecto en una escena ejecutable:

- `Player.tscn` y `Player.gd`.
- `SkillSystem.gd`.
- `SaveManager.gd` como autoload.
- `Enemy.tscn` y `Enemy.gd`.
- `MobileHUD.tscn` y joystick táctil.
- `Main.tscn` y `Main.gd` como orquestador.

## 1. Archivos finales

```text
res://
├── project.godot
├── scenes/
│   ├── enemies/
│   │   └── Enemy.tscn
│   ├── main/
│   │   └── Main.tscn
│   ├── player/
│   │   └── Player.tscn
│   └── ui/
│       └── MobileHUD.tscn
└── scripts/
    ├── enemies/
    │   └── Enemy.gd
    ├── main/
    │   └── Main.gd
    ├── player/
    │   ├── Player.gd
    │   └── SkillSystem.gd
    ├── save/
    │   └── SaveManager.gd
    └── ui/
        ├── MobileHUD.gd
        └── VirtualJoystick.gd
```

`project.godot` ya apunta a:

```ini
run/main_scene="res://scenes/main/Main.tscn"
```

Y mantiene el autoload:

```ini
[autoload]
SaveManager="*res://scripts/save/SaveManager.gd"
```

## 2. Árbol de `Main.tscn`

```text
Main (Node2D)
├── WorldBackground (Polygon2D)
├── Player (instancia Player.tscn)
├── Enemies (Node2D)
│   └── TrainingEnemy (instancia Enemy.tscn)
└── MobileHUD (instancia MobileHUD.tscn)
```

El fondo de `Polygon2D` es únicamente una superficie de prueba. Sustitúyelo por el mapa, `TileMapLayer`, decoraciones y colisiones definitivas cuando comience la fase de mundo.

## 3. Flujo al iniciar

`Main.gd` realiza las siguientes acciones en `_ready()`:

1. Asegura acciones WASD mínimas para que el proyecto funcione recién abierto.
2. Registra el jugador en `SaveManager`.
3. Carga una partida desde `user://player_save.save` si existe.
4. Conecta la señal `attack_requested` del jugador.
5. Conecta el botón de ataque del HUD.
6. Registra las señales de cada enemigo.

La carga se hace en `Main.gd`, no en `Player.gd`, para que exista un único punto de entrada y la partida no se cargue dos veces.

```gdscript
SaveManager.register_player(player)
save_was_loaded = SaveManager.load_game(player)
```

El archivo se crea automáticamente cuando se produce un guardado manual, al morir un enemigo, al morir el jugador, al pausar Android o al cerrar el juego.

## 4. Flujo del ataque

```text
MobileHUD ATACAR
       |
       v
Player.request_attack()
       |
       v
Player.attack_requested
       |
       v
Main.find_enemy_in_attack_range()
       |
       +-- sin objetivo: no daño ni XP
       |
       +-- objetivo: Enemy.take_damage(damage, Player)
                         |
                         +-- Player.register_attack_hit(xp)
                         +-- si HP = 0: bonus XP + loot
```

La función `find_enemy_in_attack_range()` busca el enemigo vivo más cercano dentro de `player_attack_range`.

Puedes ajustar desde el Inspector de `Main`:

```gdscript
@export var player_attack_range: float = 90.0
@export var player_attack_damage: int = 12
@export var player_attack_xp: int = 10
```

Este combate es una integración mínima para comprobar todas las fases. Sustitúyelo después por un sistema de alcance, animación, proyectiles y cooldown más avanzado.

## 5. Flujo del botín

Cuando `Enemy.gd` emite `loot_dropped`, `Main.gd` lo recibe:

```gdscript
if loot_type == &"gold":
    player.add_gold(amount)
elif loot_type == &"potion":
    player.heal(amount * 20)
```

Para esta fase, el botín se recoge de forma inmediata. En una siguiente iteración puedes reemplazarlo por:

- `GoldDrop.tscn` con `Area2D`.
- `PotionDrop.tscn` con animación.
- Inventario y recogida por proximidad.

## 6. Guardado y salida

`SaveManager` sigue siendo un autoload y mantiene la referencia registrada por `Main`.

Se guarda manualmente con:

```gdscript
SaveManager.save_game(player)
```

La integración también guarda:

- cuando muere un enemigo;
- cuando muere el jugador;
- cuando Android pausa la aplicación;
- cuando Godot recibe la solicitud de cerrar la ventana.

El archivo continúa estando en:

```text
user://player_save.save
```

## 7. Ejecutar en Godot 4

1. Abre `/home/ubuntu/godot-rpg-fase1` en Godot 4.
2. Abre `res://scenes/main/Main.tscn`.
3. Pulsa **Play Project**.
4. En PC, usa WASD o el joystick con el ratón.
5. Acércate al enemigo rojo de entrenamiento.
6. Pulsa **ATACAR**.
7. Cambia de arma con ESPADA, ARCO o BÁCULO.
8. Observa cómo suben las habilidades y baja HP al recibir ataques.
9. Derrota al enemigo y verifica XP, oro o poción.
10. Cierra y vuelve a abrir el juego para verificar la restauración.

Las flechas se pueden añadir en **Project > Project Settings > Input Map** junto a `move_up`, `move_down`, `move_left` y `move_right`. `Main.gd` crea WASD automáticamente si las acciones no existen.

## 8. Configuración para exportar a APK

### 8.1 Instalar requisitos de Android

En Godot 4:

1. Instala Android Studio desde la página oficial de Android Developers.
2. Desde el SDK Manager instala:
   - Android SDK Platform.
   - Android SDK Build-Tools.
   - Android SDK Platform-Tools.
   - Android SDK Command-line Tools.
3. Instala un JDK compatible con la versión de Godot 4 que estés usando.
4. Abre Godot y ve a **Editor > Editor Settings > Export > Android**.
5. Configura las rutas de:
   - Android SDK Path.
   - Java SDK Path.
6. Comprueba que Godot no muestre avisos de configuración faltante.

### 8.2 Instalar plantillas de exportación

1. Ve a **Editor > Manage Export Templates**.
2. Instala las plantillas correspondientes a tu versión de Godot.
3. Si usas una instalación de Godot personalizada, descarga las plantillas desde el mismo menú.

### 8.3 Crear preset Android

1. Ve a **Project > Export**.
2. Pulsa **Add... > Android**.
3. En **Options** configura:
   - `Application > Config > Name`: nombre visible del juego.
   - `Application > Config > Version`: por ejemplo `0.1.0`.
   - `Application > Config > Package`: identificador único, por ejemplo `com.tuestudio.rpgoffline`.
   - Orientación de pantalla: horizontal si el HUD fue diseñado para landscape.
4. Selecciona la arquitectura necesaria:
   - `arm64-v8a` para dispositivos modernos.
   - `armeabi-v7a` solo si necesitas compatibilidad antigua.
5. Para pruebas, usa un APK de debug.

### 8.4 Exportar APK de prueba

1. Conecta un dispositivo Android con depuración USB o elige una carpeta de salida.
2. En **Project > Export**, selecciona el preset Android.
3. Pulsa **Export Project**.
4. Guarda como:

   ```text
   build/RPGOffline-debug.apk
   ```

5. Instala el APK en el dispositivo.
6. Prueba joystick, botones, orientación, pausa, carga y guardado.

También puedes usar **Project > Deploy to Android** si el dispositivo aparece disponible.

### 8.5 Exportación para distribución

Para Google Play o distribución pública, crea un keystore de release y configura la firma en el preset Android. No compartas el archivo de claves ni sus contraseñas dentro del repositorio.

Un APK debug sirve para pruebas locales. Para publicar, usa una build release firmada y considera generar un AAB desde el preset Android según los requisitos actuales de Google Play.

## 9. Pruebas específicas de Android

Antes de considerar terminada la integración, verifica:

- [ ] El HUD no queda debajo de la barra de navegación o notch.
- [ ] El joystick responde a arrastre y liberación del dedo.
- [ ] Los botones no son demasiado pequeños.
- [ ] La orientación elegida se mantiene.
- [ ] La app guarda al enviarla a segundo plano.
- [ ] La app recupera posición, HP, oro, niveles y XP.
- [ ] El juego funciona sin conexión y sin depender de URLs externas.
- [ ] El botón de ataque no concede XP si no existe objetivo.
- [ ] La escena principal carga todas las instancias.

## 10. Lista de verificación final del proyecto

- [ ] `Main.tscn` es la escena principal.
- [ ] `Main.gd` registra y carga el jugador.
- [ ] `SaveManager` está configurado como autoload.
- [ ] `Player`, `SkillSystem`, `Enemy` y `MobileHUD` están instanciados.
- [ ] El enemigo detecta, persigue y ataca.
- [ ] El HUD controla movimiento y selección de arma.
- [ ] El ataque se resuelve desde Main y no desde la UI.
- [ ] Las recompensas se integran con XP y oro.
- [ ] La partida se guarda en `user://`.
- [ ] La aplicación puede exportarse como APK debug.
