# Fase 5 — Interfaz de usuario táctil para móvil

Esta fase añade un HUD en `CanvasLayer` pensado para Android y también usable con ratón en PC:

- Joystick virtual en pantalla.
- Botón principal de ataque.
- Botones táctiles para Espada, Arco y Báculo.
- Barras de HP y MP.
- Nivel de Melee, Distancia, Magia y Defensa.
- Contador de oro.

## 1. Archivos

```text
res://scripts/ui/VirtualJoystick.gd
res://scripts/ui/MobileHUD.gd
res://scenes/ui/MobileHUD.tscn
```

Instancia `MobileHUD.tscn` como hijo de la escena principal:

```text
Main (Node2D)
├── Player (instancia Player.tscn)
└── MobileHUD (instancia MobileHUD.tscn)
```

La ruta predeterminada del HUD es `../Player`. Si el jugador está en otra ubicación, selecciona `MobileHUD` y cambia `player_path` en el Inspector.

## 2. Estructura del CanvasLayer

```text
MobileHUD (CanvasLayer)
└── Root (Control)
    ├── TopLeft
    │   ├── HPLabel
    │   ├── HPBar
    │   ├── MPLabel
    │   ├── MPBar
    │   └── GoldLabel
    ├── StatsPanel
    │   ├── MeleeLabel
    │   ├── RangedLabel
    │   ├── MagicLabel
    │   └── DefenseLabel
    ├── VirtualJoystick (Control)
    └── ActionPanel
        ├── WeaponLabel
        ├── AttackButton
        └── ClassButtons
            ├── MeleeButton
            ├── RangedButton
            └── MagicButton
```

`Root` utiliza anchors de pantalla completa y los controles de acción están anclados a las esquinas inferiores. Los tamaños mínimos de botones están ampliados para que sean cómodos al tocar.

## 3. Joystick táctil

`VirtualJoystick.gd` (clase `MobileVirtualJoystick`) dibuja su base y perilla con `_draw()`, recibe `InputEventScreenTouch` y `InputEventScreenDrag`, y emite:

```gdscript
signal vector_changed(value: Vector2)
signal released
```

`MobileHUD.gd` conecta esas señales al jugador:

```gdscript
joystick.vector_changed.connect(player.set_joystick_vector)
joystick.released.connect(player.clear_joystick)
```

Por tanto, el flujo es:

```text
Dedo mueve joystick -> vector_changed(Vector2) -> Player.set_joystick_vector()
Dedo suelta        -> released              -> Player.clear_joystick()
```

El joystick entrega un vector limitado a longitud `1.0`, así las diagonales no hacen que el personaje corra más rápido.

En PC se puede probar con el botón izquierdo del ratón. En Android, los eventos táctiles se procesan directamente por el `Control`.

## 4. Botón de ataque

El botón no otorga XP por sí mismo. Solo solicita un ataque:

```gdscript
func _on_attack_button_pressed() -> void:
    player.request_attack()
    attack_button_pressed.emit()
```

`Player.gd` expone:

```gdscript
signal attack_requested

func request_attack() -> void:
    if not is_dead:
        attack_requested.emit()
```

Esto mantiene una separación importante:

- HUD: detecta el toque.
- Player: comunica la intención de atacar.
- Sistema de combate: busca objetivo, comprueba alcance, aplica daño y otorga XP solo si conecta.

Conecta el ataque desde `Main.gd`:

```gdscript
extends Node2D

@onready var player: Player = $Player
@onready var hud: MobileHUD = $MobileHUD

func _ready() -> void:
    player.attack_requested.connect(_on_player_attack_requested)
    hud.attack_button_pressed.connect(_on_attack_button_pressed)

func _on_attack_button_pressed() -> void:
    # Útil para reproducir un sonido o animación de pulsación.
    pass

func _on_player_attack_requested() -> void:
    var target: Enemy = find_enemy_in_attack_range()
    if target == null:
        return

    target.take_damage(12, player)
    # XP por golpe conectado de la Fase 2.
    player.register_attack_hit(10)
```

> No llames `register_attack_hit()` directamente desde `MobileHUD.gd`. Si lo haces, un toque sin objetivo entrenaría la habilidad.

## 5. Selección de clase/arma

Los tres botones se conectan en `MobileHUD.gd`:

```gdscript
func _on_melee_pressed() -> void:
    player.equip_weapon(SkillSystem.WeaponType.MELEE)

func _on_ranged_pressed() -> void:
    player.equip_weapon(SkillSystem.WeaponType.BOW)

func _on_magic_pressed() -> void:
    player.equip_weapon(SkillSystem.WeaponType.STAFF)
```

El resultado se refleja en `WeaponLabel` y también se emite desde `SkillSystem`:

```gdscript
signal weapon_changed(new_weapon: WeaponType)
```

Los botones corresponden a:

| Botón | Arma | Habilidad entrenada |
|---|---|---|
| ESPADA / Melee | Cuerpo a cuerpo | Melee |
| ARCO / Dist. | Arco | Distancia |
| BÁCULO / Magia | Báculo | Magia |

## 6. Barras de HP y MP

`MobileHUD.gd` escucha las señales existentes de `Player.gd`:

```gdscript
player.health_changed.connect(_on_health_changed)
player.mana_changed.connect(_on_mana_changed)
```

Las actualizaciones son:

```gdscript
func _on_health_changed(current: int, maximum: int) -> void:
    hp_bar.max_value = maximum
    hp_bar.value = current
    hp_label.text = "HP %d / %d" % [current, maximum]

func _on_mana_changed(current: int, maximum: int) -> void:
    mp_bar.max_value = maximum
    mp_bar.value = current
    mp_label.text = "MP %d / %d" % [current, maximum]
```

Cuando un enemigo hace daño o el jugador se cura, el HUD se actualiza sin que el HUD tenga que consultar cada frame.

## 7. Niveles de estadísticas

El HUD conecta las señales de `SkillSystem.gd`:

```gdscript
player.skill_system.skill_experience_changed.connect(_on_skill_experience_changed)
player.skill_system.skill_level_up.connect(_on_skill_level_up)
```

Después consulta los cuatro niveles:

```gdscript
func _refresh_all_skill_labels() -> void:
    var skills: SkillSystem = player.skill_system
    melee_label.text = "Melee: Nv. %d" % skills.get_skill_level(SkillSystem.SkillType.MELEE)
    ranged_label.text = "Distancia: Nv. %d" % skills.get_skill_level(SkillSystem.SkillType.RANGED)
    magic_label.text = "Magia: Nv. %d" % skills.get_skill_level(SkillSystem.SkillType.MAGIC)
    defense_label.text = "Defensa: Nv. %d" % skills.get_skill_level(SkillSystem.SkillType.DEFENSE)
```

Se actualiza tras XP o subida de nivel. No es necesario hacer polling en `_process()`.

## 8. Oro

El HUD también escucha la señal añadida en la Fase 3:

```gdscript
player.gold_changed.connect(_on_gold_changed)

func _on_gold_changed(new_gold: int) -> void:
    gold_label.text = "Oro: %d" % new_gold
```

Cuando el botín de la Fase 4 entregue oro:

```gdscript
func _on_enemy_loot_dropped(
        loot_type: StringName,
        amount: int,
        _world_position: Vector2
    ) -> void:
    if loot_type == &"gold":
        $Player.add_gold(amount)
```

## 9. Configuración de pantalla móvil

En **Project > Project Settings > Display > Window**:

- Configura el tamaño base, por ejemplo `1280 x 720`.
- Usa un modo de escalado adecuado para mantener proporciones.
- Prueba orientación horizontal si el juego será estilo RPG de acción.

Para que controles táctiles no interfieran con el mundo:

- `VirtualJoystick` captura sus propios eventos.
- `ActionPanel` contiene únicamente botones.
- `Root.mouse_filter = Ignore` permite que controles no interactivos de fondo no bloqueen el juego.

En dispositivos con notch o barra de navegación, aumenta los márgenes de las esquinas inferiores o utiliza `DisplayServer.screen_get_usable_rect()` para adaptar la UI.

## 10. Prueba paso a paso

1. Instancia `Player.tscn` y `MobileHUD.tscn` como hermanos bajo `Main`.
2. Comprueba que `MobileHUD.player_path` apunta a `../Player`.
3. Ejecuta en PC y mueve con el ratón sobre el joystick.
4. Pulsa ESPADA, ARCO y BÁCULO; verifica `WeaponLabel`.
5. Recibe daño y verifica HP.
6. Cura al jugador y verifica que HP se actualiza.
7. Cambia MP desde un hechizo de prueba y emite `mana_changed`.
8. Conecta `attack_requested` al sistema de combate.
9. Ataca a un enemigo; registra XP solo cuando el golpe conecta.
10. Sube una habilidad y verifica los cuatro contadores.
11. Exporta a Android y prueba con dedos reales, especialmente los botones inferiores.

## 11. Lista de verificación

- [ ] `MobileHUD.tscn` tiene `CanvasLayer` como raíz.
- [ ] El joystick mueve `Player.gd` mediante `set_joystick_vector()`.
- [ ] Al soltar el joystick se llama `clear_joystick()`.
- [ ] El botón de ataque emite una solicitud, no XP automática.
- [ ] Los tres botones cambian el arma activa.
- [ ] HP y MP muestran valor actual y máximo.
- [ ] Melee, Distancia, Magia y Defensa muestran su nivel.
- [ ] El oro se refleja tras recoger botín.
- [ ] Las señales están conectadas en `_ready()`.
- [ ] La UI funciona en PC y Android.
