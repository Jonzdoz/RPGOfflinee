# Fase 1 — Estructura principal y movimiento del jugador

Esta fase crea un jugador base para un RPG 2D **top-down**, offline y single player, compatible con teclado en PC y con un vector proveniente de un joystick táctil en Android.

## 1. Estructura recomendada del proyecto

```text
res://
├── scenes/
│   └── player/
│       └── Player.tscn
└── scripts/
    └── player/
        └── Player.gd
```

Crea las carpetas desde el panel **FileSystem** de Godot o copia los dos archivos entregados en esas rutas.

## 2. Árbol de nodos de `Player.tscn`

Crea una escena nueva con este nodo raíz:

```text
Player (CharacterBody2D)
├── CollisionShape2D
├── AnimatedSprite2D          [opcional durante esta fase]
└── Camera2D                  [opcional; útil para probar el mapa]
```

### Configuración de cada nodo

1. **Player — `CharacterBody2D`**
   - Nombre exacto: `Player`.
   - Adjunta `scripts/player/Player.gd`.
   - `Collision Layer`: 1.
   - `Collision Mask`: 1. Ajusta estas capas cuando exista el mundo.

2. **CollisionShape2D**
   - Añade una forma `CircleShape2D` o `CapsuleShape2D`.
   - Para una prueba rápida, usa un radio aproximado de 12–16 píxeles.
   - La forma debe cubrir el cuerpo del personaje, no toda la textura.

3. **AnimatedSprite2D — opcional**
   - Añade un `SpriteFrames` con una animación `idle` o una textura temporal.
   - El script no depende de este nodo, por lo que puedes incorporarlo después.

4. **Camera2D — opcional**
   - Activa `Enabled` si quieres que la cámara siga al jugador.
   - Para un juego con una cámara global, omite este nodo.

Guarda la escena como `res://scenes/player/Player.tscn`.

## 3. Script `Player.gd`

Guárdalo en `res://scripts/player/Player.gd` y adjúntalo al nodo raíz `Player`.

```gdscript
class_name Player
extends CharacterBody2D

## Se emite cuando la salud llega a cero.
signal died
## Se emite cada vez que cambia la salud: salud_actual, salud_máxima.
signal health_changed(current_health: int, maximum_health: int)
## Se emite cada vez que cambia el maná: maná_actual, maná_máximo.
signal mana_changed(current_mana: int, maximum_mana: int)

@export_category("Movement")
@export var move_speed: float = 140.0

@export_category("Attributes")
@export var max_health: int = 100
@export var max_mana: int = 50

## Valores actuales. Se pueden leer desde UI, enemigos o sistemas de combate.
var health: int
var mana: int

## El joystick virtual debe asignar un vector normalizado en el rango [-1, 1].
## Ejemplos: Vector2.ZERO = quieto, Vector2.RIGHT = derecha.
var joystick_vector: Vector2 = Vector2.ZERO

var is_dead: bool = false


func _ready() -> void:
    health = max_health
    mana = max_mana
    health_changed.emit(health, max_health)
    mana_changed.emit(mana, max_mana)


func _physics_process(_delta: float) -> void:
    if is_dead:
        velocity = Vector2.ZERO
        return

    var keyboard_vector := Input.get_vector(
        "move_left",
        "move_right",
        "move_up",
        "move_down"
    )

    # El teclado tiene prioridad cuando se está usando. Si no, se usa el joystick.
    var movement_vector := keyboard_vector
    if movement_vector == Vector2.ZERO:
        movement_vector = joystick_vector

    # Evita velocidades mayores si un control táctil entrega un vector imperfecto.
    movement_vector = movement_vector.limit_length(1.0)

    velocity = movement_vector * move_speed
    move_and_slide()


## Llamada por un joystick virtual, por ejemplo desde TouchScreenButton o una UI.
## El valor se limita para mantener una velocidad constante en diagonales.
func set_joystick_vector(value: Vector2) -> void:
    joystick_vector = value.limit_length(1.0)


## Restablece el joystick cuando el dedo deja de pulsar la UI.
func clear_joystick() -> void:
    joystick_vector = Vector2.ZERO


## Aplica daño y provoca la muerte al llegar a cero.
func take_damage(amount: int) -> void:
    if is_dead or amount <= 0:
        return

    health = maxi(health - amount, 0)
    health_changed.emit(health, max_health)

    if health == 0:
        die()


## Cura sin superar la salud máxima.
func heal(amount: int) -> void:
    if is_dead or amount <= 0:
        return

    health = mini(health + amount, max_health)
    health_changed.emit(health, max_health)


## Marca al personaje como muerto y detiene su movimiento.
## En fases posteriores puede reproducir una animación y mostrar una pantalla de derrota.
func die() -> void:
    if is_dead:
        return

    is_dead = true
    velocity = Vector2.ZERO
    died.emit()
```

> En GDScript, la indentación usa espacios. Si el editor informa un error de indentación, selecciona todo el archivo y usa **Edit > Indent** o vuelve a tabularlo con espacios consistentes.

## 4. Por qué funciona el movimiento en 8 direcciones

`Input.get_vector()` lee cuatro acciones y devuelve un vector normalizado. Por tanto, acepta:

- arriba, abajo, izquierda y derecha;
- las cuatro diagonales;
- ningún movimiento cuando no hay entrada.

La llamada a `move_and_slide()` pertenece a `CharacterBody2D` y permite que el jugador colisione con paredes u otros cuerpos definidos en las capas correspondientes.

## 5. Configurar el teclado en Godot 4

Ve a **Project > Project Settings > Input Map** y crea estas cuatro acciones:

| Acción | Teclas recomendadas |
|---|---|
| `move_up` | `W` y flecha arriba |
| `move_down` | `S` y flecha abajo |
| `move_left` | `A` y flecha izquierda |
| `move_right` | `D` y flecha derecha |

Para cada acción:

1. Escribe el nombre en **Add New Action** y pulsa **Add**.
2. Pulsa el botón `+` de la acción.
3. Elige **Physical Key** para que WASD funcione igual independientemente de la distribución del teclado.
4. Añade la tecla correspondiente.
5. Repite el proceso para las flechas si quieres ambos controles.

No es necesario crear acciones separadas para las diagonales: Godot combina las cuatro acciones.

## 6. Conectar un joystick táctil

En Android, crea una UI que calcule un vector desde el centro del joystick hacia el dedo, normalizado en el rango `[-1, 1]`. Desde el nodo de UI puedes enviar el vector al jugador:

```gdscript
# En VirtualJoystick.gd, referencia obtenida desde el Inspector.
@export var player: Player

func _on_joystick_vector_changed(value: Vector2) -> void:
    if is_instance_valid(player):
        player.set_joystick_vector(value)

func _on_joystick_released() -> void:
    if is_instance_valid(player):
        player.clear_joystick()
```

Si el joystick se implementa como un `Control`, una conexión equivalente desde un controlador puede ser:

```gdscript
func _process(_delta: float) -> void:
    $Player.set_joystick_vector($CanvasLayer/VirtualJoystick.output_vector)
```

La propiedad exacta (`output_vector`) depende de tu implementación. La única interfaz que necesita `Player.gd` es:

```gdscript
player.set_joystick_vector(Vector2(x, y))
```

Cuando el dedo se suelta, envía `Vector2.ZERO`. Mientras exista una entrada de teclado distinta de cero, el teclado tiene prioridad; al soltarlo, el jugador vuelve al joystick.

## 7. Probar salud, maná y muerte

Puedes probar temporalmente estas funciones desde otro nodo:

```gdscript
$Player.take_damage(25)
$Player.heal(10)
$Player.die()
```

También puedes conectar las señales en una UI:

```gdscript
func _ready() -> void:
    $Player.health_changed.connect(_on_player_health_changed)
    $Player.mana_changed.connect(_on_player_mana_changed)
    $Player.died.connect(_on_player_died)

func _on_player_health_changed(current: int, maximum: int) -> void:
    $CanvasLayer/HUD/HealthBar.max_value = maximum
    $CanvasLayer/HUD/HealthBar.value = current

func _on_player_mana_changed(current: int, maximum: int) -> void:
    $CanvasLayer/HUD/ManaBar.max_value = maximum
    $CanvasLayer/HUD/ManaBar.value = current

func _on_player_died() -> void:
    print("El jugador ha muerto")
```

El maná queda preparado como atributo base en esta fase. En la siguiente fase puede añadirse una función `spend_mana()` y regeneración automática sin mezclar esa lógica con el movimiento.

## 8. Escena de prueba mínima

Para validar la escena antes de construir el mapa:

1. Crea una escena `Main.tscn` con raíz `Node2D`.
2. Instancia `Player.tscn` como hijo de `Main`.
3. Coloca el jugador en `(200, 150)`.
4. Añade algunos `StaticBody2D` con `CollisionShape2D` para simular paredes.
5. Ejecuta la escena y prueba WASD, flechas y diagonales.
6. Comprueba que el jugador no atraviesa las paredes.

## 9. Lista de verificación de la Fase 1

- [ ] `Player` usa `CharacterBody2D` como nodo raíz.
- [ ] Existe un `CollisionShape2D` con una forma válida.
- [ ] Las acciones `move_up`, `move_down`, `move_left` y `move_right` están configuradas.
- [ ] WASD y flechas mueven al jugador.
- [ ] Las diagonales no son más rápidas que las direcciones cardinales.
- [ ] `set_joystick_vector()` mueve al jugador con un vector táctil.
- [ ] `clear_joystick()` detiene el movimiento táctil.
- [ ] `health`, `mana`, `take_damage()`, `heal()` y `die()` funcionan.
- [ ] La escena queda lista para añadir animaciones, combate y HUD en fases posteriores.
