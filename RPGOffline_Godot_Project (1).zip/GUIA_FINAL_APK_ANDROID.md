# Guía final — Organizar el proyecto Godot 4 y exportar a APK Android

Esta guía usa la estructura final del RPG 2D offline. El proyecto no necesita servidor ni conexión a internet para guardar o jugar.

## 1. Preparar la carpeta del proyecto

Crea o abre una carpeta de proyecto, por ejemplo:

```text
RPGOffline/
```

La carpeta debe contener `project.godot` directamente en su raíz. En Godot, se abre mediante **Import** seleccionando ese archivo o la carpeta del proyecto.

La estructura final debe ser:

```text
RPGOffline/
├── project.godot
├── scenes/
│   ├── enemies/
│   │   └── Enemy.tscn
│   ├── main/
│   │   └── Main.tscn
│   ├── player/
│   │   └── Player.tscn
│   └── ui/
│       └── MobileHUD.tscn
└── scripts/
    ├── enemies/
    │   └── Enemy.gd
    ├── main/
    │   └── Main.gd
    ├── player/
    │   ├── Player.gd
    │   └── SkillSystem.gd
    ├── save/
    │   └── SaveManager.gd
    └── ui/
        ├── MobileHUD.gd
        └── VirtualJoystick.gd
```

### Copiar los archivos entregados

Copia el contenido de la carpeta entregada respetando exactamente las rutas anteriores. En el panel **FileSystem** de Godot deberían aparecer las mismas carpetas.

No cambies nombres ni mayúsculas/minúsculas. Por ejemplo, estas rutas deben existir:

```text
res://scripts/save/SaveManager.gd
res://scenes/main/Main.tscn
res://scripts/main/Main.gd
```

## 2. Abrir y revisar el proyecto

1. Inicia **Godot Engine 4**.
2. Pulsa **Import**.
3. Selecciona la carpeta que contiene `project.godot`.
4. Abre el proyecto.
5. En el panel **FileSystem**, abre `res://scenes/main/Main.tscn`.
6. Pulsa **Play Project**.

`project.godot` debe tener como escena principal:

```ini
[application]
run/main_scene="res://scenes/main/Main.tscn"
```

Si Godot pregunta cuál escena usar como principal, elige `Main.tscn`.

## 3. Configurar `SaveManager.gd` como Autoload

El Autoload convierte `SaveManager.gd` en un Singleton global accesible desde cualquier escena.

### Método recomendado desde el editor

1. Ve a **Project > Project Settings**.
2. Abre la pestaña **Globals** o **Autoload** según la versión/interfaz de Godot 4.
3. En **Path**, pulsa el botón de selección de archivo.
4. Selecciona:

   ```text
   res://scripts/save/SaveManager.gd
   ```

5. En **Node Name** escribe exactamente:

   ```text
   SaveManager
   ```

6. Pulsa **Add**.
7. Comprueba que la entrada aparece activa en la lista.
8. Cierra Project Settings.

El nombre debe ser exactamente `SaveManager`, porque el código utiliza:

```gdscript
SaveManager.save_game(player)
SaveManager.load_game(player)
SaveManager.register_player(player)
```

### Verificar el archivo `project.godot`

Después de guardar la configuración, debe existir una sección parecida a:

```ini
[autoload]
SaveManager="*res://scripts/save/SaveManager.gd"
```

No agregues `res://` delante del nombre del Singleton al usarlo en GDScript. Se utiliza `SaveManager`, no `SaveManager.gd`.

### Comprobar que funciona

Ejecuta el juego y observa la consola. `Main.gd` registra el jugador y carga la partida con:

```gdscript
SaveManager.register_player(player)
SaveManager.load_game(player)
```

El archivo se crea en:

```text
user://player_save.save
```

La ruta `user://` es distinta en cada sistema operativo y dispositivo. No debes cambiarla por una ruta absoluta de Windows o Linux.

## 4. Revisar la escena principal

El árbol de `Main.tscn` debe ser:

```text
Main (Node2D)
├── WorldBackground (Polygon2D)
├── Player (Player.tscn)
├── Enemies (Node2D)
│   └── TrainingEnemy (Enemy.tscn)
└── MobileHUD (MobileHUD.tscn)
```

`Main.gd` se encarga de:

- Registrar al jugador en `SaveManager`.
- Cargar los datos al inicio.
- Conectar el botón de ataque.
- Buscar enemigos dentro del alcance.
- Otorgar XP cuando un golpe conecta.
- Recibir las señales de botín.
- Guardar al morir un enemigo o el jugador.

## 5. Probar el juego en el editor antes de exportar

Haz esta prueba en PC:

1. Pulsa **Play Project**.
2. Usa WASD para moverte.
3. También puedes probar el joystick con el botón izquierdo del ratón.
4. Acércate al enemigo de entrenamiento.
5. Pulsa **ATACAR**.
6. Cambia entre ESPADA, ARCO y BÁCULO.
7. Observa HP, MP, oro y niveles de estadísticas.
8. Derrota al enemigo y comprueba que aparece oro o se aplica una poción.
9. Cierra normalmente el juego.
10. Vuelve a ejecutar el proyecto.
11. Confirma que se restauran posición, salud, oro, XP y niveles.

Si el movimiento no funciona:

- Revisa **Project > Project Settings > Input Map**.
- Confirma que existen `move_up`, `move_down`, `move_left` y `move_right`.
- `Main.gd` crea WASD automáticamente si esas acciones no existen, pero puedes añadir también las flechas manualmente.

## 6. Preparar el entorno Android

### Instalar Android Studio y SDK

1. Instala Android Studio desde el sitio oficial de Android Developers.
2. Abre el **SDK Manager**.
3. Instala los componentes necesarios:
   - Android SDK Platform.
   - Android SDK Build-Tools.
   - Android SDK Platform-Tools.
   - Android SDK Command-line Tools.
4. Instala un JDK compatible con tu versión de Godot 4.
5. Reinicia Godot si lo tenías abierto.

### Configurar las rutas en Godot

1. Abre **Editor > Editor Settings**.
2. Busca **Export > Android**.
3. Configura:
   - **Android SDK Path**: carpeta raíz del Android SDK.
   - **Java SDK Path**: carpeta del JDK.
4. Comprueba que no haya indicadores rojos ni mensajes de ruta inválida.

La carpeta raíz del SDK suele contener subcarpetas como `platform-tools`, `platforms` y `build-tools`.

## 7. Instalar las plantillas de exportación

1. Ve a **Editor > Manage Export Templates**.
2. Pulsa **Download and Install** para la versión de Godot que estás utilizando.
3. Espera a que finalice la instalación.
4. Cierra la ventana.

Sin las plantillas, el preset Android puede existir pero el botón de exportación puede mostrar un error de plantilla faltante.

## 8. Crear el perfil de exportación Android

1. Ve a **Project > Export**.
2. Pulsa **Add...**.
3. Selecciona **Android**.
4. Selecciona el preset Android creado.

Configura al menos estas opciones:

| Opción | Valor de ejemplo |
|---|---|
| Application Name | RPG Offline |
| Version | 0.1.0 |
| Package / Unique Name | `com.tuestudio.rpgoffline` |
| Orientation | Landscape / Horizontal |
| Arquitectura | `arm64-v8a` |
| Build type | Debug para pruebas |

El identificador de paquete debe ser único. Usa solo letras minúsculas, números y puntos, por ejemplo:

```text
com.tuestudio.rpgoffline
```

Para dispositivos modernos, `arm64-v8a` suele ser la opción principal. Añade `armeabi-v7a` solo si necesitas compatibilidad con dispositivos antiguos y tu configuración de Godot lo permite.

## 9. Generar el archivo APK

### Exportación desde el editor

1. En **Project > Export**, selecciona el preset Android.
2. Pulsa **Export Project**.
3. Crea una carpeta `build/` dentro del proyecto si no existe.
4. Guarda el archivo como:

   ```text
   build/RPGOffline-debug.apk
   ```

5. Espera a que termine la exportación.
6. Comprueba que el archivo `.apk` existe y tiene un tamaño razonable.

El APK debug es adecuado para instalarlo en tu propio teléfono durante el desarrollo.

### Instalar directamente desde Godot

Si el teléfono está conectado y la depuración USB está activada, puedes usar:

- **Project > Deploy to Android**, si aparece disponible.

Godot compilará, instalará y ejecutará la aplicación en el dispositivo seleccionado.

## 10. Preparar el teléfono Android

En el teléfono:

1. Abre **Ajustes > Información del teléfono**.
2. Pulsa varias veces **Número de compilación** hasta activar las opciones de desarrollador.
3. En **Opciones de desarrollador**, activa **Depuración USB**.
4. Conecta el teléfono mediante un cable USB de datos.
5. Acepta en el teléfono la autorización de depuración cuando aparezca.
6. Comprueba que el dispositivo aparece en Android Studio o en las herramientas de plataforma.

Para una instalación manual, también puedes transferir `RPGOffline-debug.apk` al teléfono mediante USB, nube o mensajería de archivos.

## 11. Instalar y probar el APK manualmente

1. Abre el archivo `RPGOffline-debug.apk` en el teléfono.
2. Si Android solicita permiso para instalar desde esa fuente, habilítalo temporalmente para el gestor de archivos utilizado.
3. Confirma la instalación.
4. Abre **RPG Offline**.
5. Prueba:
   - Movimiento con joystick.
   - Botón ATACAR.
   - Espada, arco y báculo.
   - Barras HP/MP.
   - Niveles de estadísticas.
   - Oro y botín.
   - Cambio de orientación si está permitido.
6. Envía la aplicación a segundo plano.
7. Vuelve a abrirla y comprueba que el guardado se conserva.
8. Cierra y abre de nuevo para probar `load_game()`.

## 12. Prueba opcional mediante ADB

Si Android Platform-Tools está instalado y `adb` está en el PATH, desde una terminal puedes ejecutar:

```bash
adb devices
adb install -r build/RPGOffline-debug.apk
adb shell am start -n com.tuestudio.rpgoffline/.MainActivity
```

El comando `adb devices` debe mostrar el teléfono como `device`, no como `unauthorized`.

Si aparece `unauthorized`, desbloquea el teléfono y acepta el diálogo de depuración USB.

Para ver mensajes de ejecución:

```bash
adb logcat | grep -i godot
```

## 13. Validar el guardado offline

El juego guarda dentro de `user://`; no necesita permisos de almacenamiento público ni internet.

Comprueba esta secuencia:

1. Cambia la posición del jugador.
2. Obtén oro.
3. Sube Melee, Distancia, Magia o Defensa.
4. Recibe daño y conserva HP distinto al máximo.
5. Cierra o pausa la aplicación.
6. Iníciala otra vez.
7. Verifica posición, HP, oro, niveles y experiencia.

No desinstales la aplicación durante esta prueba: al desinstalar, Android normalmente elimina los datos privados de la aplicación, incluido el archivo de `user://`.

## 14. Errores frecuentes

### `SaveManager` no existe

- Revisa **Project > Project Settings > Autoload**.
- El nombre debe ser exactamente `SaveManager`.
- La ruta debe ser `res://scripts/save/SaveManager.gd`.
- Reinicia el editor si acabas de añadir el autoload.

### No se puede exportar Android

- Instala las plantillas de exportación.
- Revisa Android SDK Path y Java SDK Path.
- Asegúrate de que el preset sea **Android**, no Windows, Linux o Web.
- Comprueba que el package name sea válido.

### El teléfono no aparece

- Usa un cable USB que transfiera datos.
- Activa Depuración USB.
- Acepta la clave RSA en el teléfono.
- Ejecuta `adb devices`.
- Reinicia ADB o vuelve a conectar el dispositivo.

### El APK instala pero el HUD aparece mal

- Verifica la orientación configurada.
- Prueba distintos tamaños de pantalla.
- Ajusta los márgenes inferiores de `MobileHUD.tscn` para notch y barra de navegación.
- Confirma que el HUD sea hijo de `CanvasLayer`.

### El guardado no se restaura

- Confirma que `Main.tscn` sea la escena principal.
- Comprueba que `Main.gd` llame a `SaveManager.register_player(player)` antes de `load_game(player)`.
- No cargues la partida también desde `Player.gd`, porque la integración final usa un único punto de carga en `Main.gd`.
- No borres la aplicación entre pruebas.

## 15. APK de pruebas frente a distribución

- **Debug APK**: recomendado para el desarrollo y pruebas en tu teléfono.
- **Release APK**: requiere firma con un keystore de distribución.
- **AAB**: formato habitual para publicar en Google Play.

No guardes el keystore ni sus contraseñas en el repositorio. Para una primera prueba local, usa el APK debug.

## 16. Checklist final

- [ ] `project.godot` está en la raíz.
- [ ] `Main.tscn` es la escena principal.
- [ ] `SaveManager.gd` está en `scripts/save/`.
- [ ] `SaveManager` aparece activo en Autoload.
- [ ] Las rutas `res://` coinciden exactamente.
- [ ] El proyecto funciona en el editor.
- [ ] El joystick responde en Android.
- [ ] El ataque funciona con un enemigo.
- [ ] Las estadísticas se actualizan.
- [ ] El guardado se restaura tras reiniciar.
- [ ] Android SDK y JDK están configurados.
- [ ] Las plantillas de exportación están instaladas.
- [ ] Existe un preset Android.
- [ ] Se generó `build/RPGOffline-debug.apk`.
- [ ] El APK se instaló y probó en un teléfono real.
